# PROJECT DNA

## Definition
A local-first visual filesystem platform.

## Source of Truth
The filesystem is always the source of truth.

## Core Rules
- No import step.
- No cloud required.
- Metadata is separate from user files.
- Views render data; they never own data.

## Core Engines
1. Filesystem
2. Metadata
3. Event Bus
4. Search/Index
5. View Engine

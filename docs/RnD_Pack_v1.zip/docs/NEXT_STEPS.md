# Immediate R&D

- Study VS Code file explorer architecture.
- Study React Flow.
- Study tldraw.
- Design metadata format.
- Decide desktop framework.

# AFFiNE

Adopt:
- Infinite canvas
- Databases
- Multi-view UX

Reject:
- Internal workspace as source of truth.
- Import-first workflow.

# Obsidian

Adopt:
- Local-first
- Plugins
- Markdown

Reject:
- Vault-centric graph.
